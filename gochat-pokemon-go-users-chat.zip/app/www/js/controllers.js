function init() {
    window.initGapi(); // Calls the init function defined on the window
}

var app = angular.module('gochat.controllers', ['firebase', 'ngCordova', 'ngMap']);

app.controller('AppCtrl', function($scope, $rootScope, $timeout, $state, $ionicLoading, $ionicSideMenuDelegate, $ionicHistory, FirebaseUser, $firebaseAuth, $firebaseObject) {

  // side menu open/closed - changing navigation icons
  $scope.$watch(function () {
    return $ionicSideMenuDelegate.getOpenRatio();
  },
    function (ratio) {
      if (ratio === 1 || ratio === -1){
        $scope.isActive= true;
      } else{
          $scope.isActive = false;
    }
  });


  // go back button
  $scope.back = function() {
    $ionicHistory.goBack();
  }

  $scope.getUserStatus = function() {
    // get firebase user
    var user = FirebaseUser.status();
    if(user) {
      $rootScope.user = user.email;
      $rootScope.userUid = user.uid;
      $state.go('app.chat');
    } else {
      $state.go('app.login');
    }
  }



  $scope.getUpdateUserLocation = function(latlon) {
    // create 'user' array same id - to store user profile
      var refArray = firebase.database().ref().child("users").child($rootScope.userUid);
      var user = $firebaseObject(refArray);
      user.email = $rootScope.user;
      user.latlon = latlon;
      user.$save().then(function(ref) {

      }, function(error) {
        console.log("Error:", error);
      });
  }

  $scope.getLocation = function() {
    var onSuccess = function(position) {

      var latlon = position.coords.latitude + ',' + position.coords.longitude;

      $scope.latlon = latlon;

      $scope.getUpdateUserLocation(latlon);

    };

    // onError Callback receives a PositionError object
    //
    function onError(error) {
        $scope.message = 'Turn on your location service.';
    }

    navigator.geolocation.getCurrentPosition(onSuccess, onError);

  }

  $scope.logout = function() {
    $firebaseAuth().$signOut();
    $timeout(function() {
      $scope.getUserStatus();
      $state.go('app.login');
    }, 100)
  }


  $scope.$watch(
    function( $scope ) {
      return( $scope.getUserStatus() );
    },
    function( newValue ) {
    }
  );


})

app.controller('UserCtrl', function($scope, $rootScope, $timeout, $state, $ionicLoading, $ionicSideMenuDelegate, $firebaseObject, $firebaseAuth) {
  
  $timeout(function() {
    $scope.getUserStatus();
  },300)
  
  
  $ionicSideMenuDelegate.canDragContent(false);

  $scope.authObj = $firebaseAuth();

  // firebase login
  $scope.login = function() {

    $scope.authObj.$signInWithPopup("google").then(function(result) {
      // create 'user' array same id - to store user profile
      var refArray = firebase.database().ref().child("users").child(result.user.uid);
      var users = $firebaseObject(refArray);
      users.email = result.user.email;
      users.$save().then(function(ref) {

        $scope.getLocation();

      }, function(error) {
        console.log("Error:", error);
      });
    }).catch(function(error) {
      console.error("Authentication failed:", error);
    });
  }


   // reset password
  $scope.reset = function(email) {
    $scope.authObj.$sendPasswordResetEmail(email).then(function() {
      alert("Password reset email sent successfully!");
      $state.go('app.login');
    }).catch(function(error) {
      console.error("Error: ", error);
    });  

  }



})



app.controller('ChatCtrl', function($scope, $rootScope, $timeout, $ionicLoading, $firebaseAuth, $firebaseObject, $firebaseArray, FirebaseUser, $ionicScrollDelegate) {

  $scope.getUserStatus();

  $scope.getLocation();

  $scope.street = function() {
    $scope.street = true;
  }

  $scope.getUserOnMap = function(user) {
      var refArray = firebase.database().ref().child("users").child(user);
      var user = $firebaseObject(refArray);
      user.$loaded().then(function(data) {
        $scope.userLatlon = data.latlon;
      })
  }


  $scope.getMessages = function() {
    $timeout(function() {
      // set firebase refference for messages - if user is logged in, set to match user uid, if there is no user, show public messages
      var refArray = firebase.database().ref().child("chat");
      // create a synchronized array
      $scope.messages = $firebaseArray(refArray); // $scope.messages is your firebase array, you can add/remove/edit
      
      $scope.messages.$loaded().then(function() {
        $ionicScrollDelegate.$getByHandle('small').scrollBottom();
      });
      
    }, 100);

}

   $scope.getMessages();

  // send message
  $scope.send = function(message) {

    $scope.getLocation();

    $scope.getMessages();

      // add new items to the array
      // the message is automatically added to our Firebase database!
        $scope.messages.$add({
          text: message,
          email: $rootScope.user,
          user: $rootScope.userUid
        });
      $scope.message = '';
    }

})




app.controller('ContactCtrl', function($scope) {

 
})








app.controller('AdmobCtrl', function($scope) {

               
               $scope.showBanner = function() {               
                if(AdMob) AdMob.showBanner();
               }
               $scope.hideBanner = function() {
                if(AdMob) AdMob.hideBanner();
               }
               $scope.showInterstitial = function() {
               if(AdMob) AdMob.showInterstitial();
               }
               

                              
 
})

