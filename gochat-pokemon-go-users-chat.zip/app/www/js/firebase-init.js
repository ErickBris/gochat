
// Initialize Firebase
app.config(function() {
  var config = {
    apiKey: "AIzaSyCMNzilsOlcEt-Xujw4oCUMAB1fMP0dyUI",
    authDomain: "gocha-t.firebaseapp.com",
    databaseURL: "https://gocha-t.firebaseio.com",
    storageBucket: "gocha-t.appspot.com",
  };
  firebase.initializeApp(config);
  
      // Get a reference to the storage service, which is used to create references in your storage bucket
 // var storage = firebase.storage();

  // Create a storage reference from our storage service
//  var storageRef = storage.ref();
});