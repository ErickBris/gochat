// FIREBASE SERVICES

app.service('Firebase', function() {
    this.url = function(id) { 
        var url = "https://gocha-t.firebaseio.com";
        return url;
    };
});




// FIREBASE USER MANAGEMENT

app.service('FirebaseUser', function($firebaseAuth) {
    // get firebase user
    this.status = function() {
        var authObj = $firebaseAuth();
        var firebaseUser = authObj.$getAuth();
        if (firebaseUser) {
          return firebaseUser;
        } else {
          return false;
        }
    }
});







  